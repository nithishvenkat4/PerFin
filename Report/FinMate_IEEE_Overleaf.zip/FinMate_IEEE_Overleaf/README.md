# FinMate IEEE Paper — Overleaf Project

This is the initial IEEEtran LaTeX structure for the FinMate research paper.

## Import into Overleaf

1. Open Overleaf.
2. Select **New Project -> Upload Project**.
3. Upload `FinMate_IEEE_Overleaf.zip`.
4. Set `main.tex` as the main document if Overleaf does not select it automatically.
5. Compile with pdfLaTeX.

## Structure

- `main.tex` — IEEE paper entry point
- `references.bib` — bibliography database
- `sections/` — individual paper sections
- `figures/` — reserved for architecture and evaluation figures

## Source of truth

The FinMate technical stack and reported metrics are based on the supplied
FinMate README. External literature and references will be added separately
during the Related Work stage.

## Author information

Replace the placeholder author names, department, institution, city, and
email information in `main.tex` before submission.
